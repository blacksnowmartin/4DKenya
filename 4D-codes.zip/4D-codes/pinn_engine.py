import torch
import torch.nn as nn
import numpy as np

# 1. Define the Neural Network (The "Brain")
class HighDimPINN(nn.Module):
    def __init__(self):
        super().__init__()
        # Input: Time (t)
        # Output: 4D spatial coordinates (x, y, z, w)
        self.net = nn.Sequential(
            nn.Linear(1, 64),
            nn.Tanh(),
            nn.Linear(64, 64),
            nn.Tanh(),
            nn.Linear(64, 4)  # Outputs: x, y, z, w
        )

    def forward(self, t):
        return self.net(t)

# 2. The Physics Loss Function (The "Teacher")
# We enforce a 4D Harmonic Oscillator constraint: f''(t) + k*f(t) = 0
def physics_loss(model, t):
    t.requires_grad = True
    u = model(t)
    
    # Calculate first derivative (velocity)
    u_t = torch.autograd.grad(u, t, torch.ones_like(u), create_graph=True)[0]
    
    # Calculate second derivative (acceleration)
    u_tt = torch.autograd.grad(u_t, t, torch.ones_like(u_t), create_graph=True)[0]
    
    # Physics Law: Acceleration should equal negative position (simple harmonic motion)
    # This forces the AI to learn a valid physical trajectory in 4D space
    residual = u_tt + 16 * u # k=16 (frequency)
    return torch.mean(residual ** 2)

# 3. Training Loop (The "Simulation")
def train_model():
    model = HighDimPINN()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    # Time domain: 0 to 1 second
    t_physics = torch.linspace(0, 1, 100).view(-1, 1)
    
    print("Initializing 4DKenya AI Engine...")
    for epoch in range(2000):
        optimizer.zero_grad()
        loss = physics_loss(model, t_physics)
        loss.backward()
        optimizer.step()
        
        if epoch % 500 == 0:
            print(f"Epoch {epoch}: Physics Loss = {loss.item():.6f}")
            
    return model

# Initialize the engine once when this file is imported
engine_ai = train_model()

def get_4d_state(time_input):
    """Query the AI for the state of the system at a specific time."""
    t_tensor = torch.tensor([[time_input]], dtype=torch.float32)
    with torch.no_grad():
        coords = engine_ai(t_tensor).numpy()[0]
    return coords.tolist() # Returns [x, y, z, w]