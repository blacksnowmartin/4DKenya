import torch
import torch.nn as nn
import numpy as np
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- CONFIG ---
GRID_SIZE = 20 # Larger grid for better visuals (20x20 = 400 sectors)

# --- THE NEURAL PHYSICS ENGINE ---
# We use a Convolutional Layer to simulate "fluid dynamics" of data
city_grid = torch.zeros(1, 1, GRID_SIZE, GRID_SIZE)
diffusion = nn.Conv2d(1, 1, kernel_size=3, padding=1, bias=False)

# Custom weights: Center = retain state, Neighbors = spread energy
with torch.no_grad():
    # A "Gaussian Blur" style kernel makes movement smooth
    kernel = torch.tensor([[0.05, 0.1, 0.05],
                           [0.1,  0.4, 0.1 ],
                           [0.05, 0.1, 0.05]])
    diffusion.weight.copy_(kernel.unsqueeze(0).unsqueeze(0))

def evolve_city():
    global city_grid
    
    # 1. PHYSICS STEP: Spread the energy
    with torch.no_grad():
        city_grid = diffusion(city_grid)
    
    # 2. RANDOM ACTIVITY: Random sectors get a "burst" of data
    if np.random.rand() > 0.7:
        # Pick 3 random spots
        for _ in range(3):
            rx, ry = np.random.randint(0, GRID_SIZE, 2)
            city_grid[0, 0, rx, ry] += 0.8 # Burst energy

    # 3. DECAY: Energy naturally fades over time (prevents explosion)
    city_grid *= 0.95 
    
    # Clamp to keep visuals clean (0.0 to 1.0)
    city_grid = torch.clamp(city_grid, 0.0, 1.0)

# --- ENDPOINTS ---

@app.get("/city_pulse")
def get_pulse():
    evolve_city()
    # Flatten grid for easy sending
    return {"grid": city_grid.squeeze().flatten().tolist(), "size": GRID_SIZE}

@app.post("/trigger_event")
def trigger_event(type: str):
    global city_grid
    if type == "surge":
        city_grid += 0.5 # Massive traffic spike
    elif type == "blackout":
        city_grid *= 0.0 # Kill all power
    return {"msg": f"Event {type} processed"}

if __name__ == "__main__":
    print(f"--- NAIROBI DIGITAL TWIN ({GRID_SIZE}x{GRID_SIZE}) ONLINE ---")
    uvicorn.run(app, host="0.0.0.0", port=8000)
